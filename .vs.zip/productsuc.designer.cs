﻿namespace FinalProject
{
    partial class ProductsUC
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ProductdelName = new System.Windows.Forms.Label();
            this.cmbProductIddel = new System.Windows.Forms.ComboBox();
            this.lblDeleteProduct = new System.Windows.Forms.Label();
            this.lblProductIDdelete = new System.Windows.Forms.Label();
            this.DeleteProductBTN = new System.Windows.Forms.Button();
            this.SupplierNameedit = new System.Windows.Forms.Label();
            this.ProductNewName = new System.Windows.Forms.TextBox();
            this.ProducteditName = new System.Windows.Forms.Label();
            this.cmbProductIdedit = new System.Windows.Forms.ComboBox();
            this.cmbSupplierIDedit = new System.Windows.Forms.ComboBox();
            this.SupplierIDedit = new System.Windows.Forms.Label();
            this.ProductPriceedit = new System.Windows.Forms.NumericUpDown();
            this.lblProductAmountedit = new System.Windows.Forms.Label();
            this.ProductAmountedit = new System.Windows.Forms.NumericUpDown();
            this.ProductDescedit = new System.Windows.Forms.TextBox();
            this.lblProductIDedit = new System.Windows.Forms.Label();
            this.editProductBTN = new System.Windows.Forms.Button();
            this.lblProductNameedit = new System.Windows.Forms.Label();
            this.lblProductPriceedit = new System.Windows.Forms.Label();
            this.lblProductDescedit = new System.Windows.Forms.Label();
            this.SupplierName = new System.Windows.Forms.Label();
            this.cmbSupplierID = new System.Windows.Forms.ComboBox();
            this.SupplierID = new System.Windows.Forms.Label();
            this.ProductPrice = new System.Windows.Forms.NumericUpDown();
            this.lblProductAmount = new System.Windows.Forms.Label();
            this.ProductAmount = new System.Windows.Forms.NumericUpDown();
            this.ProductDesc = new System.Windows.Forms.TextBox();
            this.lblProductIDadd = new System.Windows.Forms.Label();
            this.AddProductBTN = new System.Windows.Forms.Button();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblProductPrice = new System.Windows.Forms.Label();
            this.lblProductDesc = new System.Windows.Forms.Label();
            this.ProductName = new System.Windows.Forms.TextBox();
            this.ProductID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ProductPriceedit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductAmountedit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductPrice)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductAmount)).BeginInit();
            this.SuspendLayout();
            // 
            // ProductdelName
            // 
            this.ProductdelName.AutoSize = true;
            this.ProductdelName.Location = new System.Drawing.Point(197, 290);
            this.ProductdelName.Name = "ProductdelName";
            this.ProductdelName.Size = new System.Drawing.Size(33, 13);
            this.ProductdelName.TabIndex = 27;
            this.ProductdelName.Text = "None";
            this.ProductdelName.Visible = false;
            // 
            // cmbProductIddel
            // 
            this.cmbProductIddel.FormattingEnabled = true;
            this.cmbProductIddel.Location = new System.Drawing.Point(61, 287);
            this.cmbProductIddel.Name = "cmbProductIddel";
            this.cmbProductIddel.Size = new System.Drawing.Size(121, 21);
            this.cmbProductIddel.TabIndex = 25;
            // 
            // lblDeleteProduct
            // 
            this.lblDeleteProduct.AutoSize = true;
            this.lblDeleteProduct.Font = new System.Drawing.Font("Arial", 16F);
            this.lblDeleteProduct.ForeColor = System.Drawing.Color.Salmon;
            this.lblDeleteProduct.Location = new System.Drawing.Point(50, 255);
            this.lblDeleteProduct.Name = "lblDeleteProduct";
            this.lblDeleteProduct.Size = new System.Drawing.Size(155, 25);
            this.lblDeleteProduct.TabIndex = 12;
            this.lblDeleteProduct.Text = "Delete Product";
            // 
            // lblProductIDdelete
            // 
            this.lblProductIDdelete.AutoSize = true;
            this.lblProductIDdelete.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductIDdelete.Location = new System.Drawing.Point(34, 290);
            this.lblProductIDdelete.Name = "lblProductIDdelete";
            this.lblProductIDdelete.Size = new System.Drawing.Size(27, 18);
            this.lblProductIDdelete.TabIndex = 13;
            this.lblProductIDdelete.Text = "ID:";
            // 
            // DeleteProductBTN
            // 
            this.DeleteProductBTN.Location = new System.Drawing.Point(61, 314);
            this.DeleteProductBTN.Name = "DeleteProductBTN";
            this.DeleteProductBTN.Size = new System.Drawing.Size(107, 23);
            this.DeleteProductBTN.TabIndex = 24;
            this.DeleteProductBTN.Text = "Delete Product";
            this.DeleteProductBTN.UseVisualStyleBackColor = true;
            this.DeleteProductBTN.Click += new System.EventHandler(this.DeleteProductBTN_Click);
            // 
            // SupplierNameedit
            // 
            this.SupplierNameedit.AutoSize = true;
            this.SupplierNameedit.Location = new System.Drawing.Point(507, 187);
            this.SupplierNameedit.Name = "SupplierNameedit";
            this.SupplierNameedit.Size = new System.Drawing.Size(33, 13);
            this.SupplierNameedit.TabIndex = 47;
            this.SupplierNameedit.Text = "None";
            this.SupplierNameedit.Visible = false;
            // 
            // ProductNewName
            // 
            this.ProductNewName.Location = new System.Drawing.Point(453, 66);
            this.ProductNewName.MaxLength = 20;
            this.ProductNewName.Name = "ProductNewName";
            this.ProductNewName.Size = new System.Drawing.Size(100, 20);
            this.ProductNewName.TabIndex = 46;
            this.ProductNewName.Tag = "";
            this.ProductNewName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductNewName_KeyPress);
            // 
            // ProducteditName
            // 
            this.ProducteditName.AutoSize = true;
            this.ProducteditName.Location = new System.Drawing.Point(473, 47);
            this.ProducteditName.Name = "ProducteditName";
            this.ProducteditName.Size = new System.Drawing.Size(33, 13);
            this.ProducteditName.TabIndex = 45;
            this.ProducteditName.Text = "None";
            this.ProducteditName.Visible = false;
            // 
            // cmbProductIdedit
            // 
            this.cmbProductIdedit.FormattingEnabled = true;
            this.cmbProductIdedit.Location = new System.Drawing.Point(388, 42);
            this.cmbProductIdedit.Name = "cmbProductIdedit";
            this.cmbProductIdedit.Size = new System.Drawing.Size(79, 21);
            this.cmbProductIdedit.TabIndex = 44;
            // 
            // cmbSupplierIDedit
            // 
            this.cmbSupplierIDedit.FormattingEnabled = true;
            this.cmbSupplierIDedit.Location = new System.Drawing.Point(432, 184);
            this.cmbSupplierIDedit.Name = "cmbSupplierIDedit";
            this.cmbSupplierIDedit.Size = new System.Drawing.Size(69, 21);
            this.cmbSupplierIDedit.TabIndex = 43;
            // 
            // SupplierIDedit
            // 
            this.SupplierIDedit.AutoSize = true;
            this.SupplierIDedit.Font = new System.Drawing.Font("Arial", 12F);
            this.SupplierIDedit.Location = new System.Drawing.Point(309, 189);
            this.SupplierIDedit.Name = "SupplierIDedit";
            this.SupplierIDedit.Size = new System.Drawing.Size(89, 18);
            this.SupplierIDedit.TabIndex = 42;
            this.SupplierIDedit.Text = "Supplier ID:";
            // 
            // ProductPriceedit
            // 
            this.ProductPriceedit.Location = new System.Drawing.Point(433, 136);
            this.ProductPriceedit.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ProductPriceedit.Name = "ProductPriceedit";
            this.ProductPriceedit.Size = new System.Drawing.Size(120, 20);
            this.ProductPriceedit.TabIndex = 41;
            // 
            // lblProductAmountedit
            // 
            this.lblProductAmountedit.AutoSize = true;
            this.lblProductAmountedit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductAmountedit.Location = new System.Drawing.Point(309, 162);
            this.lblProductAmountedit.Name = "lblProductAmountedit";
            this.lblProductAmountedit.Size = new System.Drawing.Size(65, 18);
            this.lblProductAmountedit.TabIndex = 40;
            this.lblProductAmountedit.Text = "Amount:";
            // 
            // ProductAmountedit
            // 
            this.ProductAmountedit.Location = new System.Drawing.Point(433, 158);
            this.ProductAmountedit.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ProductAmountedit.Name = "ProductAmountedit";
            this.ProductAmountedit.Size = new System.Drawing.Size(120, 20);
            this.ProductAmountedit.TabIndex = 39;
            // 
            // ProductDescedit
            // 
            this.ProductDescedit.Location = new System.Drawing.Point(312, 110);
            this.ProductDescedit.MaxLength = 30;
            this.ProductDescedit.Name = "ProductDescedit";
            this.ProductDescedit.Size = new System.Drawing.Size(241, 20);
            this.ProductDescedit.TabIndex = 38;
            this.ProductDescedit.Tag = "";
            this.ProductDescedit.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductDescedit_KeyPress);
            // 
            // lblProductIDedit
            // 
            this.lblProductIDedit.AutoSize = true;
            this.lblProductIDedit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductIDedit.Location = new System.Drawing.Point(309, 43);
            this.lblProductIDedit.Name = "lblProductIDedit";
            this.lblProductIDedit.Size = new System.Drawing.Size(27, 18);
            this.lblProductIDedit.TabIndex = 31;
            this.lblProductIDedit.Text = "ID:";
            // 
            // editProductBTN
            // 
            this.editProductBTN.Location = new System.Drawing.Point(377, 222);
            this.editProductBTN.Name = "editProductBTN";
            this.editProductBTN.Size = new System.Drawing.Size(107, 23);
            this.editProductBTN.TabIndex = 37;
            this.editProductBTN.Text = "Edit Product";
            this.editProductBTN.UseVisualStyleBackColor = true;
            this.editProductBTN.Click += new System.EventHandler(this.editProductBTN_Click);
            // 
            // lblProductNameedit
            // 
            this.lblProductNameedit.AutoSize = true;
            this.lblProductNameedit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductNameedit.Location = new System.Drawing.Point(309, 67);
            this.lblProductNameedit.Name = "lblProductNameedit";
            this.lblProductNameedit.Size = new System.Drawing.Size(54, 18);
            this.lblProductNameedit.TabIndex = 32;
            this.lblProductNameedit.Text = "Name:";
            // 
            // lblProductPriceedit
            // 
            this.lblProductPriceedit.AutoSize = true;
            this.lblProductPriceedit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductPriceedit.Location = new System.Drawing.Point(309, 137);
            this.lblProductPriceedit.Name = "lblProductPriceedit";
            this.lblProductPriceedit.Size = new System.Drawing.Size(49, 18);
            this.lblProductPriceedit.TabIndex = 33;
            this.lblProductPriceedit.Text = "Price:";
            // 
            // lblProductDescedit
            // 
            this.lblProductDescedit.AutoSize = true;
            this.lblProductDescedit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductDescedit.Location = new System.Drawing.Point(309, 91);
            this.lblProductDescedit.Name = "lblProductDescedit";
            this.lblProductDescedit.Size = new System.Drawing.Size(92, 18);
            this.lblProductDescedit.TabIndex = 34;
            this.lblProductDescedit.Text = "Description:";
            // 
            // SupplierName
            // 
            this.SupplierName.AutoSize = true;
            this.SupplierName.Location = new System.Drawing.Point(226, 184);
            this.SupplierName.Name = "SupplierName";
            this.SupplierName.Size = new System.Drawing.Size(33, 13);
            this.SupplierName.TabIndex = 46;
            this.SupplierName.Text = "None";
            this.SupplierName.Visible = false;
            // 
            // cmbSupplierID
            // 
            this.cmbSupplierID.FormattingEnabled = true;
            this.cmbSupplierID.Location = new System.Drawing.Point(153, 180);
            this.cmbSupplierID.Name = "cmbSupplierID";
            this.cmbSupplierID.Size = new System.Drawing.Size(67, 21);
            this.cmbSupplierID.TabIndex = 30;
            // 
            // SupplierID
            // 
            this.SupplierID.AutoSize = true;
            this.SupplierID.Font = new System.Drawing.Font("Arial", 12F);
            this.SupplierID.Location = new System.Drawing.Point(30, 185);
            this.SupplierID.Name = "SupplierID";
            this.SupplierID.Size = new System.Drawing.Size(89, 18);
            this.SupplierID.TabIndex = 29;
            this.SupplierID.Text = "Supplier ID:";
            // 
            // ProductPrice
            // 
            this.ProductPrice.Location = new System.Drawing.Point(154, 132);
            this.ProductPrice.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ProductPrice.Name = "ProductPrice";
            this.ProductPrice.Size = new System.Drawing.Size(120, 20);
            this.ProductPrice.TabIndex = 28;
            // 
            // lblProductAmount
            // 
            this.lblProductAmount.AutoSize = true;
            this.lblProductAmount.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductAmount.Location = new System.Drawing.Point(30, 158);
            this.lblProductAmount.Name = "lblProductAmount";
            this.lblProductAmount.Size = new System.Drawing.Size(65, 18);
            this.lblProductAmount.TabIndex = 27;
            this.lblProductAmount.Text = "Amount:";
            // 
            // ProductAmount
            // 
            this.ProductAmount.Location = new System.Drawing.Point(154, 154);
            this.ProductAmount.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ProductAmount.Name = "ProductAmount";
            this.ProductAmount.Size = new System.Drawing.Size(120, 20);
            this.ProductAmount.TabIndex = 26;
            // 
            // ProductDesc
            // 
            this.ProductDesc.Location = new System.Drawing.Point(33, 106);
            this.ProductDesc.MaxLength = 30;
            this.ProductDesc.Name = "ProductDesc";
            this.ProductDesc.Size = new System.Drawing.Size(241, 20);
            this.ProductDesc.TabIndex = 25;
            this.ProductDesc.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductDesc_KeyPress);
            // 
            // lblProductIDadd
            // 
            this.lblProductIDadd.AutoSize = true;
            this.lblProductIDadd.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductIDadd.ForeColor = System.Drawing.Color.DarkCyan;
            this.lblProductIDadd.Location = new System.Drawing.Point(30, 39);
            this.lblProductIDadd.Name = "lblProductIDadd";
            this.lblProductIDadd.Size = new System.Drawing.Size(27, 18);
            this.lblProductIDadd.TabIndex = 13;
            this.lblProductIDadd.Text = "ID:";
            // 
            // AddProductBTN
            // 
            this.AddProductBTN.Location = new System.Drawing.Point(98, 218);
            this.AddProductBTN.Name = "AddProductBTN";
            this.AddProductBTN.Size = new System.Drawing.Size(107, 23);
            this.AddProductBTN.TabIndex = 24;
            this.AddProductBTN.Text = "Add Product";
            this.AddProductBTN.UseVisualStyleBackColor = true;
            this.AddProductBTN.Click += new System.EventHandler(this.AddProductBTN_Click);
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductName.Location = new System.Drawing.Point(30, 63);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(54, 18);
            this.lblProductName.TabIndex = 14;
            this.lblProductName.Text = "Name:";
            // 
            // lblProductPrice
            // 
            this.lblProductPrice.AutoSize = true;
            this.lblProductPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductPrice.Location = new System.Drawing.Point(30, 133);
            this.lblProductPrice.Name = "lblProductPrice";
            this.lblProductPrice.Size = new System.Drawing.Size(49, 18);
            this.lblProductPrice.TabIndex = 15;
            this.lblProductPrice.Text = "Price:";
            // 
            // lblProductDesc
            // 
            this.lblProductDesc.AutoSize = true;
            this.lblProductDesc.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductDesc.Location = new System.Drawing.Point(30, 87);
            this.lblProductDesc.Name = "lblProductDesc";
            this.lblProductDesc.Size = new System.Drawing.Size(92, 18);
            this.lblProductDesc.TabIndex = 17;
            this.lblProductDesc.Text = "Description:";
            // 
            // ProductName
            // 
            this.ProductName.Location = new System.Drawing.Point(174, 65);
            this.ProductName.MaxLength = 20;
            this.ProductName.Name = "ProductName";
            this.ProductName.Size = new System.Drawing.Size(100, 20);
            this.ProductName.TabIndex = 20;
            this.ProductName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductName_KeyPress);
            // 
            // ProductID
            // 
            this.ProductID.Location = new System.Drawing.Point(174, 39);
            this.ProductID.MaxLength = 10;
            this.ProductID.Name = "ProductID";
            this.ProductID.Size = new System.Drawing.Size(100, 20);
            this.ProductID.TabIndex = 19;
            this.ProductID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductID_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 16F);
            this.label1.ForeColor = System.Drawing.Color.Salmon;
            this.label1.Location = new System.Drawing.Point(50, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 25);
            this.label1.TabIndex = 48;
            this.label1.Text = "Add Product";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 16F);
            this.label2.ForeColor = System.Drawing.Color.Salmon;
            this.label2.Location = new System.Drawing.Point(329, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 25);
            this.label2.TabIndex = 49;
            this.label2.Text = "Edit Product";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // ProductsUC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ProductdelName);
            this.Controls.Add(this.SupplierNameedit);
            this.Controls.Add(this.SupplierName);
            this.Controls.Add(this.cmbProductIddel);
            this.Controls.Add(this.ProductNewName);
            this.Controls.Add(this.lblDeleteProduct);
            this.Controls.Add(this.lblProductIDdelete);
            this.Controls.Add(this.ProducteditName);
            this.Controls.Add(this.DeleteProductBTN);
            this.Controls.Add(this.cmbSupplierID);
            this.Controls.Add(this.cmbProductIdedit);
            this.Controls.Add(this.cmbSupplierIDedit);
            this.Controls.Add(this.SupplierID);
            this.Controls.Add(this.SupplierIDedit);
            this.Controls.Add(this.ProductPrice);
            this.Controls.Add(this.ProductPriceedit);
            this.Controls.Add(this.lblProductIDadd);
            this.Controls.Add(this.lblProductAmountedit);
            this.Controls.Add(this.lblProductAmount);
            this.Controls.Add(this.ProductAmountedit);
            this.Controls.Add(this.ProductID);
            this.Controls.Add(this.ProductDescedit);
            this.Controls.Add(this.ProductAmount);
            this.Controls.Add(this.lblProductIDedit);
            this.Controls.Add(this.ProductName);
            this.Controls.Add(this.editProductBTN);
            this.Controls.Add(this.lblProductNameedit);
            this.Controls.Add(this.ProductDesc);
            this.Controls.Add(this.lblProductPriceedit);
            this.Controls.Add(this.lblProductDesc);
            this.Controls.Add(this.lblProductDescedit);
            this.Controls.Add(this.lblProductPrice);
            this.Controls.Add(this.AddProductBTN);
            this.Controls.Add(this.lblProductName);
            this.ForeColor = System.Drawing.Color.DarkCyan;
            this.Name = "ProductsUC";
            this.Size = new System.Drawing.Size(1104, 480);
            this.Load += new System.EventHandler(this.ProductsUC_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ProductPriceedit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductAmountedit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductPrice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ProductAmount)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ProductdelName;
        private System.Windows.Forms.ComboBox cmbProductIddel;
        private System.Windows.Forms.Label lblDeleteProduct;
        private System.Windows.Forms.Label lblProductIDdelete;
        private System.Windows.Forms.Button DeleteProductBTN;
        private System.Windows.Forms.Label SupplierNameedit;
        private System.Windows.Forms.TextBox ProductNewName;
        private System.Windows.Forms.Label ProducteditName;
        private System.Windows.Forms.ComboBox cmbProductIdedit;
        private System.Windows.Forms.ComboBox cmbSupplierIDedit;
        private System.Windows.Forms.Label SupplierIDedit;
        private System.Windows.Forms.NumericUpDown ProductPriceedit;
        private System.Windows.Forms.Label lblProductAmountedit;
        private System.Windows.Forms.NumericUpDown ProductAmountedit;
        private System.Windows.Forms.TextBox ProductDescedit;
        private System.Windows.Forms.Label lblProductIDedit;
        private System.Windows.Forms.Button editProductBTN;
        private System.Windows.Forms.Label lblProductNameedit;
        private System.Windows.Forms.Label lblProductPriceedit;
        private System.Windows.Forms.Label lblProductDescedit;
        private System.Windows.Forms.Label SupplierName;
        private System.Windows.Forms.ComboBox cmbSupplierID;
        private System.Windows.Forms.Label SupplierID;
        private System.Windows.Forms.NumericUpDown ProductPrice;
        private System.Windows.Forms.Label lblProductAmount;
        private System.Windows.Forms.NumericUpDown ProductAmount;
        private System.Windows.Forms.TextBox ProductDesc;
        private System.Windows.Forms.Label lblProductIDadd;
        private System.Windows.Forms.Button AddProductBTN;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblProductPrice;
        private System.Windows.Forms.Label lblProductDesc;
        private System.Windows.Forms.TextBox ProductName;
        private System.Windows.Forms.TextBox ProductID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
